package com.example.hellophonegap;


import android.R.string;
import android.net.Uri;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Menu;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;


import org.apache.cordova.DroidGap;

public class MainActivity extends DroidGap  {

	@SuppressLint("SetJavaScriptEnabled")

	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	 super.onCreate(savedInstanceState);
	 super.init(); // Calling this is necessary to make this work
	 appView.addJavascriptInterface(this, "MainActivity");

	 /* "this" points the to the object of the current activity. "MainActivity" is used to refer "this" object in JavaScript as in Step 3. */

	 	// window.location
	 //navigator.app.loadUrl("file:///android_asset/www/home.html");

	 super.loadUrl("file:///android_asset/www/index.html");
	  
	  
	}
	
	
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	

	public void call(String smsPhoneNumJava )
	{
		
		
		try {
	        Intent callIntent = new Intent(Intent.ACTION_CALL);
	        callIntent.setData(Uri.parse("tel:"+smsPhoneNumJava.toString()));
	        startActivity(callIntent);
	    } catch (ActivityNotFoundException e) {
	        Log.e("helloandroid dialing example", "Call failed", e);
	    }
	}
	
	
	
	

	// window.MainActivity.sendSMS(smslongitudeJava,  smsLatitudeJava , smsSpecialInstJava,  smsPhoneNumJava   );  
	public void sendSMS(String smslongitudeJava, String smsLatitudeJava, String smsSpecialInstJava , String smsPhoneNumJava)
	{
	    try { 
	    	
	       // String phoneNo ="6472985260";
	    	String phoneNo=smsPhoneNumJava;
	    	
	    	String smsBodyMessage =" My Current Location \n"
	    				+ "Latitude :"+smsLatitudeJava
	    				+ "\nLongitude :"+ smslongitudeJava
	    				+ "\n\nSpecial Instruction \n "+smsSpecialInstJava;
	    	
			  try {
				SmsManager smsManager = SmsManager.getDefault();
				smsManager.sendTextMessage(phoneNo, null, smsBodyMessage, null, null);
				Toast.makeText(getApplicationContext(), "SMS Sent!",
							Toast.LENGTH_LONG).show();
				
			  } catch (Exception e) {
				Toast.makeText(getApplicationContext(),
					"SMS faild, please try again later!",
					Toast.LENGTH_LONG).show();
				e.printStackTrace();
			  }
	    	
	    	
	        
	        
	    } catch (ActivityNotFoundException e) {
	        Log.e("helloandroid dialing example", "Call failed", e);
	    }
	}
	
	
	
	

	
	
	
	
}
