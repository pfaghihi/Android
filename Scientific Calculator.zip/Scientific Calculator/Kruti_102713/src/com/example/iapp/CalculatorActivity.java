package com.example.iapp;


import android.R;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;
import de.congrace.exp4j.Calculable;
import de.congrace.exp4j.ExpressionBuilder;
import de.congrace.exp4j.UnknownFunctionException;
import de.congrace.exp4j.UnparsableExpressionException;

public class CalculatorActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    
    // Parameter v stands for the view that was clicked
    public void onButtonClick(View v) throws UnknownFunctionException, UnparsableExpressionException
    {
    	TextView inputDisplay = (TextView) findViewById(R.id.textView2); 
    	TextView outputDisplay = (TextView) findViewById(R.id.textView1); 
    	String input = inputDisplay.getText().toString();
    	String output = outputDisplay.getText().toString();
    	
    	
    	if(R.id.Button03== v.getId())
    	{ 
    		input = input + "1";
    		output = "1";
    		inputDisplay.setText(input) ;
    		outputDisplay.setText(output);
    	}
    	if(R.id.Button08== v.getId())
    	{ 
    		input = input + "2";
    		output = "2";
    		inputDisplay.setText(input) ;
    		outputDisplay.setText(output);
    	}
    	if(R.id.Button05== v.getId())
    	{ 
    		input = input + "3";
    		output = "3";
    		inputDisplay.setText(input) ;
    		outputDisplay.setText(output);
    	}
    	if(R.id.Button06== v.getId())
    	{ 
    		input = input + "4";
    		output = "4";
    		inputDisplay.setText(input) ;
    		outputDisplay.setText(output);
    	}
    	if(R.id.Button04== v.getId())
    	{
    		input = input + "5";
    		output = "5";
    		inputDisplay.setText(input) ;
    		outputDisplay.setText(output);
    	}
    	if(R.id.Button07 == v.getId())
    	{
    		input = input + "6";
    		output = "6";
    		inputDisplay.setText(input) ;
    		outputDisplay.setText(output);
    	}
    	if(R.id.button1== v.getId())
    	{
    		input = input + "7";
    		output = "7";
    		inputDisplay.setText(input) ;
    		outputDisplay.setText(output);
    	}
    	if(R.id.Button01== v.getId())
    	{ 
    		input = input + "8";
    		output = "8";
    		inputDisplay.setText(input) ;
    		outputDisplay.setText(output);
    	}
    	if(R.id.Button02== v.getId())
    	{ 
    		input = input + "9";
    		output = "9";
    		inputDisplay.setText(input) ;
    		outputDisplay.setText(output);
    	}
    	if(R.id.button2== v.getId())
    	{ 
    		input = input + "0";
    		output = "0";
    		inputDisplay.setText(input) ;
    		outputDisplay.setText(output);
    	}


    	if(R.id.Button12== v.getId())
    	{
    		input = input + "+";
    		inputDisplay.setText(input) ;
    	}
    	
    	if(R.id.button3== v.getId())
    	{ 
    		input = input + ".";
    		inputDisplay.setText(input) ;
    	}
    	if(R.id.Button10== v.getId())
    	{
    		input = input + "*";
    		inputDisplay.setText(input) ;
    	}
    	if(R.id.Button11== v.getId())
    	{ 
    		input = input + "-";
    		inputDisplay.setText(input) ;
    	}
    	if(R.id.Button09== v.getId())
    	{ 
    		input = input + "/";
    		inputDisplay.setText(input) ;
    	}
    	
    	//Clear
    	if(R.id.Button14 == v.getId())
    	{
    		inputDisplay.setText("") ;
    		outputDisplay.setText("") ;
    	}
    	//Back
    	if(R.id.Button13 == v.getId())
    	{
    		input = input.substring(0,input.length()-1);
    		inputDisplay.setText(input) ;
    		
    		output = output.substring(0,input.length()-1);
    		outputDisplay.setText(output) ;
    	}
    	
    	if(R.id.button4 == v.getId())
    	{
    		output = evaluateExpression(input);
    		outputDisplay.setText(output) ;
    	}
    	
    }
    
    public String evaluateExpression (String expression) throws UnknownFunctionException, UnparsableExpressionException
    {

    	 Calculable calc = new ExpressionBuilder(expression).build();
    	 double output = calc.calculate();
		return Double.toString(output);
    }

    
}
