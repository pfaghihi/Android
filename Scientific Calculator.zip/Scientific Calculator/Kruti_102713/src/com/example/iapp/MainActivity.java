package com.example.iapp;


import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.ContactsContract.Contacts;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void onClickCalculator(View v)
	{
		
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setClassName("com.example.calculator", "com.example.calculator.MainActivity");
		startActivity(intent);
		
	}
	
	public void showContacts(View v)
	{
	    // Creates a new intent for sending to the device's contacts application
	    Intent iContacts = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);  
	    startActivityForResult(iContacts, 1); 
	}
	
	public void onLogIn(View v)
	{
		
		Intent iSignIn = new Intent(this, LoginActivity.class );
		startActivity(iSignIn);
	}
	
	
	
	
	public boolean onOptionsItemSelected(MenuItem item) {
	    // Handle item selection
	    switch (item.getItemId()) {
	        case R.id.calculator:
	        	Intent iCal = new Intent(this,  CalculatorActivity.class);
	        	startActivity(iCal);
	        	break;
	        case R.id.Map:
	        	Intent iMap = new Intent(this, IMapActivity.class);
	        	startActivity(iMap);
	        	break;
	        	
	        case R.id.action_settings:
	        	Intent iSettings= new Intent(this, SettingsActivity.class);
	        	startActivity(iSettings);
	        	break;

	        default:
	            return super.onOptionsItemSelected(item);
	    }
	    return true;
	}

}
