package com.example.iapp;

public class UserDatabase {
	
	String _userId = "";
	String _password = "";
	
	
	//Default Constructor
	
	public UserDatabase()
	{}
	
	
	public void User (String userId, String password)
	{
		this._userId = userId;
		this._password = password;
	}
	
	
	
	// getting userId
	public String getUserId(){
		return this._userId;
	}
	
	// setting userID
	public void setUserId(String userId){
		this._userId = userId;
	}
	
	// getting password
	public String getPassword(){
		return this._password;
	}
	
	// setting password
	public void setPassword(String password){
		this._password = password;
	}
	

}
