package com.example.iapp;

import java.util.ArrayList;
import java.util.List;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDatabaseHandler extends SQLiteOpenHelper {
	
		// All Static variables
		// Database Version
		private static final int DATABASE_VERSION = 1;

		// Database Name
		private static final String DATABASE_NAME = "iapp_own";

		// Contacts table name
		private static final String TABLE_USERS = "person_info";

		// Contacts Table Columns names
		private static final String KEY_USER_ID = "userId";
		private static final String KEY_PASSWORD = "password";
		
		public UserDatabaseHandler(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}
		
		
		public void onCreate(SQLiteDatabase db) {
			String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USERS + "("
					+ KEY_USER_ID + " INTEGER PRIMARY KEY," + KEY_PASSWORD + " TEXT," + ")";
			db.execSQL(CREATE_USER_TABLE);
		}
		
		// Adding new contact
		void addUser(UserDatabase user) {
			SQLiteDatabase db = this.getWritableDatabase();

			ContentValues values = new ContentValues();
			values.put(KEY_USER_ID, user.getUserId()); // Contact Name
			values.put(KEY_PASSWORD, user.getPassword()); // Contact Phone

			// Inserting Row
			db.insert(TABLE_USERS, null, values);
			db.close(); // Closing database connection
		}


		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			
		}

}
